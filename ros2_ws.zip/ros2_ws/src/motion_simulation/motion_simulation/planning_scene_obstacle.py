import rclpy
from geometry_msgs.msg import Pose
from moveit_msgs.msg import CollisionObject, PlanningScene
from moveit_msgs.srv import ApplyPlanningScene
from rclpy.node import Node
from shape_msgs.msg import SolidPrimitive


class PlanningSceneObstacle(Node):
    def __init__(self):
        super().__init__("planning_scene_obstacle")
        self.client = self.create_client(ApplyPlanningScene, "/apply_planning_scene")
        self.timer = self.create_timer(1.0, self.apply_obstacle_once)
        self.sent = False

    def apply_obstacle_once(self):
        if self.sent:
            return
        if not self.client.wait_for_service(timeout_sec=0.1):
            self.get_logger().info("Waiting for /apply_planning_scene...")
            return

        table = SolidPrimitive()
        table.type = SolidPrimitive.BOX
        table.dimensions = [0.36, 0.26, 0.03]

        table_pose = Pose()
        table_pose.orientation.w = 1.0
        table_pose.position.x = 0.55
        table_pose.position.y = 0.0
        table_pose.position.z = 0.18

        table_object = CollisionObject()
        table_object.header.frame_id = "world"
        table_object.id = "work_table_collision"
        table_object.primitives.append(table)
        table_object.primitive_poses.append(table_pose)
        table_object.operation = CollisionObject.ADD

        cube = SolidPrimitive()
        cube.type = SolidPrimitive.BOX
        cube.dimensions = [0.06, 0.06, 0.06]

        cube_pose = Pose()
        cube_pose.orientation.w = 1.0
        cube_pose.position.x = 0.55
        cube_pose.position.y = 0.0
        cube_pose.position.z = 0.225

        cube_object = CollisionObject()
        cube_object.header.frame_id = "world"
        cube_object.id = "grasp_cube_collision"
        cube_object.primitives.append(cube)
        cube_object.primitive_poses.append(cube_pose)
        cube_object.operation = CollisionObject.ADD

        scene = PlanningScene()
        scene.is_diff = True
        scene.world.collision_objects.append(table_object)
        scene.world.collision_objects.append(cube_object)

        request = ApplyPlanningScene.Request()
        request.scene = scene
        future = self.client.call_async(request)
        future.add_done_callback(self.done_callback)
        self.sent = True

    def done_callback(self, future):
        result = future.result()
        if result and result.success:
            self.get_logger().info("Added table and grasp cube to the planning scene.")
        else:
            self.get_logger().error("Failed to apply planning scene obstacle.")


def main(args=None):
    rclpy.init(args=args)
    node = PlanningSceneObstacle()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
