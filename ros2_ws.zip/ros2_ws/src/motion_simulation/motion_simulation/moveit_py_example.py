import rclpy
from moveit.core.robot_state import RobotState
from moveit.planning import MoveItPy


def main(args=None):
    rclpy.init(args=args)
    moveit = MoveItPy(node_name="moveit_py_example")

    try:
        arm = moveit.get_planning_component("arm")
        arm.set_start_state_to_current_state()

        goal_state = RobotState(moveit.get_robot_model())
        goal_state.set_to_default_values()
        goal_state.set_joint_group_positions("arm", [0.6, 0.35, -0.5, 0.25])
        goal_state.update()

        arm.set_goal_state(robot_state=goal_state)
        plan_result = arm.plan()

        if not plan_result:
            print("Planning failed.")
            return

        print("Planning succeeded.")
        node = rclpy.create_node("moveit_py_example_params")
        execute_trajectory = node.get_parameter_or(
            "execute_trajectory",
            rclpy.Parameter("execute_trajectory", rclpy.Parameter.Type.BOOL, False),
        ).value
        node.destroy_node()

        if execute_trajectory:
            moveit.execute(plan_result.trajectory, controllers=[])
            print("Trajectory execution requested.")
    finally:
        moveit.shutdown()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
