from glob import glob

from setuptools import find_packages, setup

package_name = 'motion_simulation'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
        ('share/' + package_name + '/config', glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user',
    maintainer_email='youhong2006@gmail.com',
    description='TODO: Package description',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'trajectory_publisher = motion_simulation.trajectory_publisher:main',
            'moveit_py_example_node = motion_simulation.moveit_py_example:main',
            'planning_scene_obstacle_node = motion_simulation.planning_scene_obstacle:main',
        ],
    },
)
