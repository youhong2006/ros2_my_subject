import os

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    RegisterEventHandler,
    SetEnvironmentVariable,
    TimerAction,
)
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch.substitutions import EnvironmentVariable
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare
from launch.conditions import IfCondition
from moveit_configs_utils import MoveItConfigsBuilder


def generate_launch_description():
    moveit_config = MoveItConfigsBuilder(
        "test_robot", package_name="my_robot_moveit_config"
    ).to_moveit_configs()

    world_file = PathJoinSubstitution(
        [FindPackageShare("test_robot_gazebo"), "worlds", "empty.world"]
    )
    xacro_file = PathJoinSubstitution(
        [FindPackageShare("my_robot_moveit_config"), "config", "test_robot.urdf.xacro"]
    )
    rviz_config = PathJoinSubstitution(
        [FindPackageShare("my_robot_moveit_config"), "config", "moveit_safe.rviz"]
    )
    bridge_config = PathJoinSubstitution(
        [FindPackageShare("test_robot_gazebo"), "config", "bridge_config.yaml"]
    )

    robot_description = {
        "robot_description": ParameterValue(Command(["xacro ", xacro_file]), value_type=str)
    }

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution(
                [FindPackageShare("ros_gz_sim"), "launch", "gz_sim.launch.py"]
            )
        ),
        launch_arguments={
            "gz_args": ["-r ", world_file],
            "on_exit_shutdown": "true",
        }.items(),
    )

    clock_bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        output="screen",
        parameters=[{"config_file": bridge_config}],
    )

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[
            robot_description,
            {
                "publish_frequency": 30.0,
                "use_sim_time": True,
            },
        ],
    )

    spawn_robot = Node(
        package="ros_gz_sim",
        executable="create",
        output="screen",
        arguments=["-topic", "/robot_description", "-name", "test_robot", "-z", "0.1"],
    )

    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        arguments=["joint_state_broadcaster", "-c", "/controller_manager"],
    )

    arm_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        arguments=["arm_controller", "-c", "/controller_manager"],
    )

    gripper_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        output="screen",
        arguments=["gripper_controller", "-c", "/controller_manager"],
    )

    move_group_configuration = {
        "publish_robot_description_semantic": True,
        "allow_trajectory_execution": True,
        "publish_planning_scene": True,
        "publish_geometry_updates": True,
        "publish_state_updates": True,
        "publish_transforms_updates": True,
        "monitor_dynamics": False,
        "use_sim_time": True,
    }

    move_group = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",
        parameters=[moveit_config.to_dict(), move_group_configuration],
        additional_env={"DISPLAY": os.environ.get("DISPLAY", "")},
    )

    rviz = Node(
        package="rviz2",
        executable="rviz2",
        output="screen",
        arguments=["-d", LaunchConfiguration("rviz_config")],
        parameters=[
            moveit_config.to_dict(),
            robot_description,
            {"use_sim_time": LaunchConfiguration("rviz_use_sim_time")},
        ],
        condition=IfCondition(LaunchConfiguration("use_rviz")),
        additional_env={
            "LIBGL_ALWAYS_SOFTWARE": "1",
            "MESA_GL_VERSION_OVERRIDE": "3.3",
            "QT_OPENGL": "software",
            "QT_QUICK_BACKEND": "software",
            "QT_XCB_NO_MITSHM": "1",
            "SVGA_VGPU10": "0",
        },
    )

    start_after_spawn = RegisterEventHandler(
        OnProcessExit(
            target_action=spawn_robot,
            on_exit=[joint_state_broadcaster_spawner],
        )
    )

    start_after_joint_states = RegisterEventHandler(
        OnProcessExit(
            target_action=joint_state_broadcaster_spawner,
            on_exit=[arm_controller_spawner],
        )
    )

    start_after_arm_controller = RegisterEventHandler(
        OnProcessExit(
            target_action=arm_controller_spawner,
            on_exit=[gripper_controller_spawner],
        )
    )

    start_after_gripper_controller = RegisterEventHandler(
        OnProcessExit(
            target_action=gripper_controller_spawner,
            on_exit=[
                TimerAction(
                    period=5.0,
                    actions=[
                        move_group,
                        TimerAction(period=2.0, actions=[rviz]),
                    ],
                )
            ],
        )
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "rviz_config",
                default_value=rviz_config,
                description="RViz config file. Use moveit.rviz for the full MotionPlanning plugin.",
            ),
            DeclareLaunchArgument(
                "use_rviz",
                default_value="true",
                description="Start RViz after controllers are active.",
            ),
            DeclareLaunchArgument(
                "rviz_use_sim_time",
                default_value="true",
                description="Use sim time in RViz so MotionPlanning reads Gazebo joint states as current.",
            ),
            SetEnvironmentVariable("GZ_PARTITION", "test_robot_gazebo"),
            SetEnvironmentVariable(
                "GZ_SIM_RESOURCE_PATH",
                [
                    PathJoinSubstitution(
                        [FindPackageShare("test_robot_gazebo"), "models"]
                    ),
                    ":",
                    EnvironmentVariable("GZ_SIM_RESOURCE_PATH", default_value=""),
                ],
            ),
            gazebo,
            clock_bridge,
            robot_state_publisher,
            spawn_robot,
            start_after_spawn,
            start_after_joint_states,
            start_after_arm_controller,
            start_after_gripper_controller,
        ]
    )
