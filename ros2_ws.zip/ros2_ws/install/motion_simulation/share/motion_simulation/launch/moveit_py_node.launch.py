from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from moveit_configs_utils import MoveItConfigsBuilder


def generate_launch_description():
    moveit_config = MoveItConfigsBuilder(
        "test_robot", package_name="my_robot_moveit_config"
    ).to_moveit_configs()

    moveit_py_config = PathJoinSubstitution(
        [FindPackageShare("motion_simulation"), "config", "moveit_py.yaml"]
    )

    return LaunchDescription(
        [
            DeclareLaunchArgument("use_sim_time", default_value="true"),
            DeclareLaunchArgument("execute_trajectory", default_value="false"),
            Node(
                package="motion_simulation",
                executable="moveit_py_example_node",
                name="moveit_py_example",
                output="screen",
                parameters=[
                    moveit_config.to_dict(),
                    moveit_py_config,
                    {
                        "execute_trajectory": LaunchConfiguration(
                            "execute_trajectory"
                        ),
                        "use_sim_time": LaunchConfiguration("use_sim_time"),
                    },
                ],
            ),
        ]
    )
